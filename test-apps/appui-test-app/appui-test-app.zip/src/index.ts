/*---------------------------------------------------------------------------------------------
* Copyright (c) Bentley Systems, Incorporated. All rights reserved.
* See LICENSE.md in the project root for license terms and full copyright notice.
*--------------------------------------------------------------------------------------------*/

// react-scripts requires an index.ts file in this location. Using it to import the code
// from the frontend.

import "./frontend/index";
